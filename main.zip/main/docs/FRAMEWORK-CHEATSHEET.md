# Справка по CSS-фреймворку Bootstrap 5.3

**Задание 1. Изучение документации.**
Версия: **Bootstrap 5.3.3** (локально — `css/bootstrap.min.css`, `js/bootstrap.bundle.min.js`).
Документация: <https://getbootstrap.com/docs/5.3/>

---

## 1. Сетка (Grid)

12-колоночная flex-сетка на классе `.row`.

| Класс | Назначение |
|-------|------------|
| `.container` | Контейнер с фиксированной шириной по точкам перелома |
| `.container-fluid` | Контейнер во всю ширину окна |
| `.container-{sm,md,lg,xl,xxl}` | «Тянущийся» до указанной точки, далее — фиксированный |
| `.row` | Ряд-обёртка колонок (отрицательные отступы + flex-wrap) |
| `.col` | Равная автоматическая колонка |
| `.col-{1..12}` | Колонка на N/12 ширины (без точки перелома — все экраны) |
| `.col-{sm,md,lg,xl,xxl}-{1..12}` | Ширина колонки начиная с точки перелома |
| `.col-{bp}-auto` | Колонка по содержимому |
| `.offset-{bp}-{1..11}` | Смещение колонки |
| `.g-{0..5}`, `.gx-*`, `.gy-*` | Отступы между колонками (gutter) |
| `.order-{bp}-*` | Порядок вывода |
| `.align-items-*`, `.justify-content-*` | Выравнивание во flex-ряду |

Пример из проекта (`catalog.html`):
```html
<div class="row g-4">
  <div class="col-12">Фильтры — на всех экранах 12/12</div>
  <div class="col-lg-3">Боковая информация — 3/12 от 992px</div>
  <div class="col-12 col-lg-9">Основная зона — 12/12 на мобильных, 9/12 на десктопе</div>
</div>
```

## 2. Точки перелома (breakpoints)

| Точка | Класс-инфикс | Медиазапрос | Устройство |
|-------|--------------|-------------|------------|
| Extra small | *(нет)* | `< 576px` | Телефон |
| Small | `sm` | `≥ 576px` | Большой телефон |
| Medium | `md` | `≥ 768px` | Планшет |
| Large | `lg` | `≥ 992px` | Ноутбук |
| Extra large | `xl` | `≥ 1200px` | Десктоп |
| Extra extra large | `xxl` | `≥ 1400px` | Широкий экран |

Подход — **mobile-first**: базовые классы действуют на всех экранах, инфиксы `-md/-lg` уточняют поведение от указанной ширины.

## 3. Переменные темы (CSS-переменные `--bs-*`)

Bootstrap 5.3 собран на CSS-переменных, которые можно переопределить в своём `:root` (Задание 4 — файл `css/theme-bootstrap.css`).

| Переменная | Что задаёт |
|------------|-----------|
| `--bs-primary`, `--bs-primary-rgb` | Основной цвет и его RGB |
| `--bs-secondary`, `--bs-success`, `--bs-info`, `--bs-warning`, `--bs-danger` | Цвета статусов |
| `--bs-body-bg`, `--bs-body-color` | Фон и цвет текста страницы |
| `--bs-heading-color` | Цвет заголовков |
| `--bs-emphasis-color` | Цвет акцентного текста |
| `--bs-font-sans-serif`, `--bs-body-font-family`, `--bs-body-font-size` | Шрифт |
| `--bs-border-radius`, `--bs-border-radius-sm/-lg/-pill` | Радиусы скругления |
| `--bs-box-shadow`, `--bs-box-shadow-sm/-lg` | Тени |
| `--bs-border-color`, `--bs-border-color-translucent` | Цвет границ |
| `--bs-link-color`, `--bs-link-hover-color` | Ссылки |

> Важно: переменные уровня компонента (например `--bs-btn-bg` у `.btn-primary`) заданы литералами, поэтому `.btn-primary` и подобные переопределяются точечно.

## 4. Набор компонентов (использованные классы)

| Компонент | Классы |
|-----------|--------|
| Шапка/меню | `.navbar`, `.navbar-expand-lg`, `.navbar-dark`, `.navbar-brand`, `.navbar-toggler`, `.navbar-nav`, `.nav-item`, `.nav-link`, `.collapse` |
| Кнопки | `.btn`, `.btn-primary`, `.btn-outline-primary`, `.btn-warning`, `.btn-sm`, `.d-grid` |
| Карточки | `.card`, `.card-body`, `.card-title`, `.card-header`, `.card-text`, `.h-100` |
| Таблицы | `.table`, `.table-striped`, `.table-hover`, `.table-bordered`, `.table-responsive`, `.align-middle` |
| Пагинация | `.pagination`, `.page-item`, `.page-link`, `.active`, `.disabled` |
| Формы | `.form-label`, `.form-control`, `.form-select`, `.form-check` |
| Индикаторы | `.badge`, `.text-bg-primary/-secondary/-success/-info`, `.alert`, `.alert-primary` |
| Навигация | `.breadcrumb`, `.breadcrumb-item` |
| Утилиты | `m*/p*` (отступы 0–5), `gap-*`, `text-*`, `bg-*`, `d-*`, `flex-*`, `border-*`, `rounded-*`, `shadow*`, `w-*`, `visually-hidden` |

## 5. Быстрые правила

- `.row` — только для колонок; между колонками отступы задаёт `g-*`.
- Не задавать фиксированные `width` колонкам — это ломает сетку.
- Переопределять тему нужно **после** `bootstrap.min.css` и **до** собственных стилей портала.
- Свои стили с равной специфичностью перекрывают Bootstrap, если подключены позже (используется в Задании 6).
