/* =========================================================
   app.js — интерактив портала «Социальный туризм по Беларуси»
   ДЕНЬ 6: версия на jQuery (jQuery 3.7.1 подключена выше).
   • Задание 2 — переключатель светлой/тёмной темы
   • Задание 3–6 — чек-лист, комментарии, итоги, сохранение
   • Задание 7 — модальное окно
   • Задание 8 — поиск/фильтрация с подсветкой
   ========================================================= */
(function () {
  'use strict';

  /* =========================================================
     ЗАДАНИЕ 2. Переключатель темы (jQuery)
     Класс .theme-dark вешается на <html>; значения хранятся в
     localStorage и восстанавливаются при следующей загрузке.
     ========================================================= */
  (function initTheme() {
    var THEME_KEY = 'portal-theme';
    var $root = $(document.documentElement);

    function applyTheme(theme) {
      var dark = theme === 'dark';
      $root.toggleClass('theme-dark', dark);
      $('.theme-toggle')
        .attr('aria-pressed', dark ? 'true' : 'false')
        .attr('aria-label', dark ? 'Включить светлую тему' : 'Включить тёмную тему');
    }

    function storeTheme(theme) {
      try { localStorage.setItem(THEME_KEY, theme); } catch (e) { /* приватный режим */ }
    }

    var saved = null;
    try { saved = localStorage.getItem(THEME_KEY); } catch (e) { /* ignore */ }
    if (saved !== 'dark' && saved !== 'light') {
      saved = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark' : 'light';
    }
    applyTheme(saved);

    $('.theme-toggle').on('click', function () {
      var next = $root.hasClass('theme-dark') ? 'light' : 'dark';
      applyTheme(next);
      storeTheme(next);
    });
  })();

  /* =========================================================
     ЗАДАНИЕ 8. Поиск и фильтрация (jQuery)
     Фильтрует карточки «Разделы проекта» на главной, подсвечивает
     совпадения тегом <mark> и показывает количество результатов.
     ========================================================= */
  (function initSearch() {
    var $input = $('#projects-search');
    if (!$input.length) return;

    var $grid = $('#projects-grid');
    var $count = $('#projects-count');
    var $empty = $('#projects-empty');
    if (!$grid.length) return;

    var CARDS = [];
    $grid.find('.card').each(function () {
      CARDS.push({
        $card: $(this),
        $title: $(this).find('.card__title'),
        $text: $(this).find('.card__text'),
        title: $(this).find('.card__title').text(),
        text: $(this).find('.card__text').text()
      });
    });
    var total = CARDS.length;

    function escapeHtml(value) {
      return String(value).replace(/[&<>"]/g, function (ch) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch];
      });
    }

    /* Обёртка найденного фрагмента в <mark>, остальной текст экранируется */
    function highlight(text, query) {
      if (!query) return escapeHtml(text);
      var pattern = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
      var out = '', last = 0, m;
      while ((m = pattern.exec(text)) !== null) {
        out += escapeHtml(text.slice(last, m.index));
        out += '<mark>' + escapeHtml(m[0]) + '</mark>';
        last = m.index + m[0].length;
        if (m.index === pattern.lastIndex) pattern.lastIndex++;
      }
      out += escapeHtml(text.slice(last));
      return out;
    }

    function run() {
      var raw = $input.val().trim();
      var query = raw.toLowerCase();
      var found = 0;

      CARDS.forEach(function (item) {
        var haystack = (item.title + ' ' + item.text).toLowerCase();
        var match = !query || haystack.indexOf(query) !== -1;
        item.$card.toggleClass('is-hidden', !match);
        // Занятие 9: на сетке скрываем и ячейку колонки, чтобы не оставалось «дыр»
        item.$card.parent('[class*="col-"]').toggleClass('d-none', !match);
        item.$title.html(highlight(item.title, raw));
        item.$text.html(highlight(item.text, raw));
        if (match) found++;
      });

      $count.text(query ? 'Найдено: ' + found + ' из ' + total : 'Всего элементов: ' + total);
      if ($empty.length) $empty.prop('hidden', !(query && found === 0));
    }

    $input.on('input', run).on('search', run);
    run();
  })();

  /* ЗАДАНИЕ 7 (день 6). Собственное модальное окно удалено на занятии 11:
     окна построены на компоненте modal Bootstrap (data-bs-toggle="modal"),
     фокус, Esc и возврат фокуса обеспечивает сам компонент. */

  /* =========================================================
     ЗАДАНИЯ 3–6. Чек-лист (jQuery)
     Выбор ответа, комментарий к несоответствиям, расчёт доли
     «Соответствует», автосохранение и очистка с подтверждением.
     ========================================================= */
  (function initChecklist() {
    var $form = $('#checklist-form');
    if (!$form.length) return;

    var STORAGE_KEY = 'portal-checklist';
    var $items = $form.find('.check-item');
    var $percent = $('#checklist-percent');
    var $counts = $('#checklist-counts');
    var $progress = $('#checklist-progress');
    var $panel = $('#checklist-result');
    var $status = $('#checklist-status');
    var $clearBtn = $('#checklist-clear');
    var total = $items.length;

    function readState() {
      var answers = {};
      var comments = {};
      $items.each(function () {
        var id = this.dataset.item;
        var $checked = $(this).find('input[type="radio"]:checked');
        if ($checked.length) answers[id] = $checked.val();
        var $area = $(this).find('.check-item__textarea');
        var value = $area.length ? $.trim($area.val()) : '';
        if (value) comments[id] = value;
      });
      return { answers: answers, comments: comments };
    }

    function applyState(state) {
      var answers = state.answers || {};
      var comments = state.comments || {};
      $items.each(function () {
        var id = this.dataset.item;
        if (answers[id]) {
          var $radio = $(this).find('input[type="radio"][value="' + answers[id] + '"]');
          if ($radio.length) $radio.prop('checked', true);
        }
        var $area = $(this).find('.check-item__textarea');
        if (comments[id] && $area.length) $area.val(comments[id]);
      });
    }

    /* Задание 4: подсветка позиции и показ комментария для «Не соответствует» */
    function updateVisual(item) {
      var $item = $(item);
      var $checked = $item.find('input[type="radio"]:checked');
      var value = $checked.length ? $checked.val() : null;

      $item.removeClass('check-item--ok check-item--warning check-item--na');
      $item.find('.check-option').removeClass('is-selected');

      if ($checked.length) {
        $checked.closest('.check-option').addClass('is-selected');
        if (value === 'yes') $item.addClass('check-item--ok');
        else if (value === 'no') $item.addClass('check-item--warning');
        else $item.addClass('check-item--na');
      }

      $item.find('.check-item__comment').prop('hidden', value !== 'no');
    }

    /* Задание 5: расчёт доли «Соответствует» с цветовой индикацией */
    function compute() {
      var yes = 0, no = 0, na = 0, answered = 0;
      $items.each(function () {
        var $checked = $(this).find('input[type="radio"]:checked');
        if (!$checked.length) return;
        answered++;
        if ($checked.val() === 'yes') yes++;
        else if ($checked.val() === 'no') no++;
        else na++;
      });

      var scored = yes + no;                       /* «Не применимо» не влияет на долю */
      var percent = scored ? Math.round((yes / scored) * 100) : 0;
      var level = 'empty';
      if (scored > 0) {
        if (percent >= 80) level = 'green';
        else if (percent >= 50) level = 'yellow';
        else level = 'red';
      }

      $percent.text(scored ? percent + '%' : '—');
      $counts.text('Соответствует: ' + yes + ' · Не соответствует: ' + no +
        ' · Не применимо: ' + na + ' · Без ответа: ' + (total - answered));
      $panel.removeClass('result--green result--yellow result--red result--empty')
        .addClass('result--' + level);
      /* Занятие 11: индикатор выполнения — компонент progress Bootstrap */
      if ($progress.length) {
        var value = scored ? percent : 0;
        var bar = { green: 'bg-success', yellow: 'bg-warning', red: 'bg-danger', empty: 'bg-secondary' }[level];
        $progress.attr('aria-valuenow', value);
        $progress.find('.progress-bar')
          .removeClass('bg-success bg-warning bg-danger bg-secondary').addClass(bar)
          .css('width', value + '%').text(scored ? value + '%' : '');
      }
      applyFilter();
    }

    /* Занятие 11: переключатель «Показывать только несоответствия» */
    var $onlyNo = $('#only-mismatch');
    function applyFilter() {
      var only = $onlyNo.is(':checked');
      $items.each(function () {
        var isNo = $(this).find('input[value="no"]').is(':checked');
        $(this).toggleClass('d-none', only && !isNo);
      });
    }
    $onlyNo.on('change', applyFilter);

    /* Занятие 11: уведомление о сохранении (toast). Строка статуса
       на странице остаётся — уведомление не единственный источник */
    function toast(text) {
      var el = document.getElementById('checklist-toast');
      if (!el || !window.bootstrap) return;
      $('#checklist-toast-text').text(text);
      bootstrap.Toast.getOrCreateInstance(el, { delay: 4000 }).show();
    }

    /* Задание 6: сохранение результатов */
    function save() {
      var state = readState();
      state.updated = new Date().toISOString();
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) { /* ignore */ }
      $status.text('Сохранено автоматически: ' + new Date().toLocaleTimeString('ru-RU'));
    }

    function refresh() {
      $items.each(function () { updateVisual(this); });
      compute();
      save();
    }

    $form.on('change', function (e) {
      if ($(e.target).is('input[type="radio"]')) refresh();
    });
    $form.on('input', function (e) {
      if ($(e.target).hasClass('check-item__textarea')) refresh();
    });
    $form.on('submit', function (e) {
      e.preventDefault();
      save();
      $status.text('Результаты сохранены: ' + new Date().toLocaleTimeString('ru-RU'));
      toast('Результаты чек-листа сохранены в браузере.');
    });

    /* Задание 6: полная очистка с подтверждением */
    $clearBtn.on('click', function () {
      if (!window.confirm('Очистить все ответы и комментарии? Это действие нельзя отменить.')) return;
      try { localStorage.removeItem(STORAGE_KEY); } catch (e) { /* ignore */ }
      $form.trigger('reset');
      $items.find('.check-item__textarea').val('');
      $items.each(function () { updateVisual(this); });
      compute();
      $status.text('Результаты очищены.');
      toast('Результаты чек-листа очищены.');
    });

    /* Восстановление при повторном открытии страницы */
    var saved = null;
    try { saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null'); } catch (e) { /* ignore */ }
    if (saved) applyState(saved);
    $items.each(function () { updateVisual(this); });
    compute();
    $status.text(saved && saved.updated
      ? 'Восстановлено: ' + new Date(saved.updated).toLocaleString('ru-RU')
      : 'Изменения сохраняются автоматически.');
  })();
})();