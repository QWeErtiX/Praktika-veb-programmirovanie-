/* =========================================================
   registry.js — Каталог записей (день 6, jQuery)
   • Задание 5 — асинхронная загрузка $.getJSON
   • Задание 6 — поиск/фильтрация, подсветка, сброс
   • Задание 7 — сортировка и индикация направления
   • Задание 8 — анимация строк и подсветка при наведении
   • Задание 9 — статистика через setInterval (гистограммы)
   ========================================================= */
(function () {
  'use strict';

  var $loading = $('#records-loading');
  var $error = $('#records-error');
  var $empty = $('#records-empty');
  var $count = $('#records-count');
  var $direction = $('#records-direction');
  var $table = $('#records-table');
  var $body = $('#records-body');
  var $search = $('#records-search');
  var $section = $('#records-section');
  var $sort = $('#records-sort');
  var $reset = $('#records-reset');
  var $statsStatus = $('#stats-status');
  var $histSections = $('#hist-sections');
  var $histCategories = $('#hist-categories');

  var SECTION_LABELS = { 1: 'РАЗДЕЛ 1', 2: 'РАЗДЕЛ 2', 3: 'РАЗДЕЛ 3' };
  var DATA = [];

  function escapeHtml(value) {
    return String(value).replace(/[&<>"]/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch];
    });
  }

  function highlight(text, query) {
    if (!query) return escapeHtml(text);
    var pattern = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    var out = '', last = 0, m;
    while ((m = pattern.exec(text)) !== null) {
      out += escapeHtml(text.slice(last, m.index));
      out += '<mark>' + escapeHtml(m[0]) + '</mark>';
      last = m.index + m[0].length;
      if (m.index === pattern.lastIndex) pattern.lastIndex++;
    }
    out += escapeHtml(text.slice(last));
    return out;
  }

  function formatDate(iso) {
    var parts = iso.split('-');
    return parts[2] + '.' + parts[1] + '.' + parts[0];
  }

  function matchesFilters(record, query) {
    if (query) {
      var haystack = (record.name + ' ' + record.category + ' ' + record.number + ' ' + record.annotation).toLowerCase();
      if (haystack.indexOf(query) === -1) return false;
    }
    var sec = $section.val();
    if (sec !== '0' && String(record.section) !== sec) return false;
    return true;
  }

  function sortRecords(list) {
    var mode = $sort.val();
    var sorted = list.slice();
    if (mode === 'name-asc') {
      sorted.sort(function (a, b) { return a.name.localeCompare(b.name, 'ru'); });
    } else {
      sorted.sort(function (a, b) {
        return mode === 'date-asc' ? a.date.localeCompare(b.date) : b.date.localeCompare(a.date);
      });
    }
    return sorted;
  }

  /* Задание 7: индикация активного направления сортировки */
  function updateDirection() {
    var mode = $sort.val();
    var text, cls;
    if (mode === 'name-asc') {
      text = 'наименование (А–Я)';
      cls = 'registry-direction--name';
    } else if (mode === 'date-asc') {
      text = 'дата ▲ возрастание (сначала старые)';
      cls = 'registry-direction--date';
    } else {
      text = 'дата ▼ убывание (сначала новые)';
      cls = 'registry-direction--date';
    }
    $direction.removeClass('registry-direction--name registry-direction--date')
      .addClass(cls)
      .text('Сортировка: ' + text);
  }

  /* Задание 6: фильтрация, подсветка, счётчик; Задание 8: анимация строк */
  function render() {
    var query = $search.val().trim().toLowerCase();
    var filtered = DATA.filter(function (r) { return matchesFilters(r, query); });
    var rows = sortRecords(filtered);

    if (!filtered.length) {
      $body.empty();
      $table.addClass('is-hidden');
      $empty.text('Ничего не найдено. Измените запрос или сбросьте фильтры.').removeAttr('hidden');
      $count.text(DATA.length ? 'Найдено записей: 0 из ' + DATA.length : 'Записей: 0');
      return;
    }

    $empty.attr('hidden', '');
    $table.removeClass('is-hidden');
    $count.text('Найдено записей: ' + filtered.length + ' из ' + DATA.length);

    var fragment = rows.map(function (r, i) {
      return $('<tr></tr>')
        .append($('<td></td>').text(i + 1))
        .append($('<td></td>').html(highlight(r.name, query)))
        .append($('<td></td>').html(highlight(r.category, query)))
        .append($('<td></td>').html(highlight(r.number, query)))
        .append($('<td></td>').attr('data-sortdate', r.date).text(formatDate(r.date)))
        .append($('<td></td>').text(SECTION_LABELS[r.section] || r.section))
        .append($('<td></td>').html(highlight(r.annotation, query)));
    });

    $body.empty();
    /* Появление строк с задержками средствами jQuery */
    $.each(fragment, function (i, $row) {
      $row.hide().appendTo($body).delay(i * 70).fadeIn(240);
    });
  }

  /* Задание 9: статистика по разделам и категориям через setInterval */
  function runStats() {
    if (!DATA.length) return;

    var bySection = {};
    var byCategory = {};
    DATA.forEach(function (r) {
      bySection[r.section] = (bySection[r.section] || 0) + 1;
      byCategory[r.category] = (byCategory[r.category] || 0) + 1;
    });

    var sectionSteps = [1, 2, 3].map(function (s) {
      return { label: SECTION_LABELS[s], count: bySection[s] || 0, $list: $histSections };
    });
    var categorySteps = Object.keys(byCategory).sort().map(function (c) {
      return { label: c, count: byCategory[c], $list: $histCategories };
    });
    var steps = sectionSteps.concat(categorySteps);

    var max = 1;
    steps.forEach(function (s) { if (s.count > max) max = s.count; });

    var idx = 0;
    var timer = setInterval(function () {
      if (idx >= steps.length) {
        clearInterval(timer);
        $statsStatus.text('Статистика рассчитана: ' + DATA.length + ' записей.');
        return;
      }
      var step = steps[idx++];
      var pct = Math.round((step.count / max) * 100);
      var $item = $('<li class="histogram__item"></li>');
      $item.append($('<span class="histogram__label"></span>').text(step.label));
      $item.append($('<div class="histogram__track"></div>'));
      $item.find('.histogram__track')
        .append($('<div class="histogram__fill"></div>').css('width', '0%'))
        .append($('<span class="histogram__value"></span>').text(String(step.count)));
      $item.appendTo(step.$list);
      $item.find('.histogram__fill').animate({ width: pct + '%' }, 300);
      $statsStatus.text('Расчёт статистики… позиция ' + idx + ' из ' + steps.length);
    }, 320);
  }

  /* Задание 5: загрузка данных с индикатором и обработкой ошибки */
  function load() {
    $loading.removeAttr('hidden');
    $error.attr('hidden', '');
    $empty.attr('hidden', '');
    $table.addClass('is-hidden');
    $body.empty();
    $histSections.empty();
    $histCategories.empty();
    $count.text('Загрузка каталога…');
    $statsStatus.text('Ожидание загрузки данных…');

    $.getJSON('assets/data/records.json')
      .done(function (data) {
        $loading.attr('hidden', '');
        DATA = Array.isArray(data) ? data : [];
        if (!DATA.length) {
          $count.text('Записей: 0');
          $statsStatus.text('В каталоге нет записей — статистика недоступна.');
          $empty.text('В каталоге нет записей. Добавьте данные в assets/data/records.json.').removeAttr('hidden');
          return;
        }
        render();
        updateDirection();
        runStats();
      })
      .fail(function () {
        $loading.attr('hidden', '');
        var fallback = window.PORTAL_RECORDS;
        if (Array.isArray(fallback) && fallback.length) {
          DATA = fallback;
          render();
          updateDirection();
          runStats();
          $statsStatus.text('Файл records.json недоступен (открыто без сервера) — использованы локальные данные.');
          return;
        }
        $count.text('Загрузка не выполнена');
        $statsStatus.text('Статистика недоступна: файл данных не загружен.');
        $error.removeAttr('hidden');
      });
  }

  /* Задание 6: сброс всех фильтров */
  function resetFilters() {
    $search.val('');
    $section.val('0');
    $sort.val('name-asc');
    updateDirection();
    render();
  }

  $search.on('input', render);
  $section.on('change', render);
  $sort.on('change', function () { updateDirection(); render(); });
  $reset.on('click', resetFilters);

  /* Задание 8: подсветка строки при наведении средствами jQuery */
  $body.on('mouseenter', 'tr', function () { $(this).addClass('is-hover'); });
  $body.on('mouseleave', 'tr', function () { $(this).removeClass('is-hover'); });

  load();
})();