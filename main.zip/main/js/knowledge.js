/* =========================================================
   knowledge.js — Проверка знаний (день 7, jQuery UI)
   • Задание 2 — форма обучающегося + datepicker
   • Задание 3 — вопросы вкладками (tabs)
   • Задание 4 — slider (уровень) + progressbar (прогресс)
   • Задание 5 — sortable: порядок действий и его проверка
   • Задание 6 — диалоги: справка и результат
   • Задание 7 — проверка формы (русские сообщения)
   • Задание 8 — расчёт процента и уровня
   • Задание 9 — submitHandler: localStorage + подтверждение
   ========================================================= */
(function ($) {
  'use strict';

  var STORAGE_KEY = 'portal-knowledge-result';
  var $form = $('#knowledge-form');
  if (!$form.length) return;

  var $questions = $('#question-tabs .question');
  var total = $questions.length;

  /* ---------- Поле: очистка/установка ошибки ---------- */
  function fieldError($field, message) {
    var ok = !message;
    $field.closest('.kn-field').toggleClass('is-invalid', !ok);
    $field.toggleClass('is-invalid', !ok).attr('aria-invalid', ok ? null : 'true');
    $('#' + $field.attr('id') + '-error').text(message || '');
    return ok;
  }

  /* ---------- Проверка отдельных правил ---------- */
  function isEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
  }

  function isRealDate(value) {
    var m = value.trim().match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
    if (!m) return false;
    var day = +m[1], month = +m[2], year = +m[3];
    if (month < 1 || month > 12 || day < 1 || day > 31) return false;
    var d = new Date(year, month - 1, day);
    return d.getFullYear() === year && d.getMonth() === month - 1 && d.getDate() === day;
  }

  /* ---------- Задание 7. Валидация формы ---------- */
  function validate() {
    var valid = true;
    function check(ok) { if (!ok) valid = false; }

    var surname = $('#student-surname').val().trim();
    var name = $('#student-name').val().trim();
    var group = $('#student-group').val().trim();

    check(fieldError($('#student-surname'),
      surname.length >= 2 ? '' : 'Фамилия обязательна (минимум 2 символа).'));
    check(fieldError($('#student-name'),
      name.length >= 2 ? '' : 'Имя обязательно (минимум 2 символа).'));
    check(fieldError($('#student-group'),
      group.length >= 3 ? '' : 'Учебная группа обязательна (минимум 3 символа).'));

    var dateVal = $('#check-date').val().trim();
    check(fieldError($('#check-date'),
      dateVal && isRealDate(dateVal) ? '' : 'Укажите корректную дату проверки в формате ДД.ММ.ГГГГ.'));

    var emailVal = $('#student-email').val().trim();
    check(fieldError($('#student-email'),
      !emailVal ? 'Адрес электронной почты обязателен.'
        : isEmail(emailVal) ? '' : 'Некорректный адрес электронной почты (например, ivanov@example.by).'));

    var numVal = $('#check-number').val().trim();
    var num = Number(numVal);
    check(fieldError($('#check-number'),
      !numVal ? 'Номер проверки обязателен.'
        : !/^\d+$/.test(numVal) ? 'Номер проверки — это число, введите цифры без букв.'
          : (num < 1000 || num > 9999) ? 'Номер проверки должен быть в диапазоне от 1000 до 9999.' : ''));

    return valid;
  }

  /* ---------- Задание 8. Подсчёт ответов и уровня ---------- */
  function answersInfo() {
    var answered = 0, correct = 0;
    $questions.each(function () {
      var $checked = $(this).find('input:checked');
      if ($checked.length) {
        answered++;
        if ($checked.data('correct')) correct++;
        $(this).addClass('question--done');
      } else {
        $(this).removeClass('question--done');
      }
    });
    return { answered: answered, correct: correct, total: total };
  }

  function refreshAnswers() {
    var info = answersInfo();
    $('#answer-progress').attr('aria-valuenow', info.answered)
      .find('.progress-bar').css('width', Math.round(info.answered / total * 100) + '%')
      .text(info.answered ? info.answered + ' / ' + total : '');
    $('#answer-progress-label').text('Отвечено ' + info.answered + ' из ' + total);
  }

  function resultLevel(percent) {
    if (percent >= 80) return 'высокий';
    if (percent >= 50) return 'удовлетворительный';
    return 'низкий';
  }

  /* Задание 3: вкладки — компонент nav-tabs Bootstrap (занятие 11), инициализация не нужна */

  /* ---------- Задание 2. Календарь даты проверки (datepicker, ru) ---------- */
  $('#check-date').datepicker({
    dateFormat: 'dd.mm.yy',
    firstDay: 1,
    changeMonth: true,
    changeYear: true,
    yearRange: 'c-10:c+1',
    dayNamesMin: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
    monthNames: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
      'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'],
    prevText: '‹',
    nextText: '›',
    onSelect: function () { fieldError($('#check-date'), ''); }
  });

  /* ---------- Задание 4. Ползунок самооценки: form-range (занятие 11) ---------- */
  var $slider = $('#level-slider');
  var $levelValue = $('#level-value');
  function levelText() { $levelValue.text('Значение: ' + $slider.val() + ' из 10'); }
  $slider.on('input change', levelText);
  levelText();

  /* Индикатор прогресса — компонент progress Bootstrap (занятие 11) */
  $('#question-tabs').on('change', 'input[type="radio"]', refreshAnswers);

  /* ---------- Задание 5. Порядок действий (sortable) ---------- */
  function resetSortMarks() {
    $('#sort-steps li').removeClass('is-correct is-wrong');
    $('#sort-status').attr('class', 'sort-status').text('');
  }

  $('#sort-steps').sortable({
    axis: 'y',
    forcePlaceholderSize: true,
    placeholder: 'ui-sortable-placeholder',
    start: resetSortMarks
  });

  $('#shuffle-steps').on('click', function () {
    resetSortMarks();
    var items = $('#sort-steps li').get();
    for (var i = items.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = items[i]; items[i] = items[j]; items[j] = t;
    }
    $('#sort-steps').append(items);
  });

  $('#check-order').on('click', function () {
    var wrong = [];
    $('#sort-steps li').each(function (i) {
      var ok = Number($(this).attr('data-step')) === i + 1;
      $(this).toggleClass('is-correct', ok).toggleClass('is-wrong', !ok);
      if (!ok) wrong.push(i + 1);
    });
    if (!wrong.length) {
      $('#sort-status').attr('class', 'sort-status sort-status--ok')
        .text('Отлично! Порядок действий верный, этап зачтён.');
    } else {
      $('#sort-status').attr('class', 'sort-status sort-status--err')
        .text('Неверно: позиции ' + wrong.join(', ') + '. Перемешайте шаги и попробуйте снова.');
    }
  });

  /* ---------- Задание 6. Окна — компонент modal Bootstrap (занятие 11) ---------- */
  /* «Справка» открывается атрибутами data-bs-toggle/data-bs-target кнопки */
  var resultModal = window.bootstrap
    ? bootstrap.Modal.getOrCreateInstance(document.getElementById('result-dialog')) : null;

  /* ---------- Задание 9. submitHandler: предотвращение отправки + сохранение ---------- */
  $form.on('submit', function (e) {
    e.preventDefault();

    if (!validate()) {
      $('#form-status').attr('class', 'form-status form-status--err')
        .text('Форма содержит ошибки. Проверьте выделенные поля.');
      var firstInvalid = $('#knowledge-form input.is-invalid').first();
      if (firstInvalid.length) firstInvalid.trigger('focus');
      return;
    }

    var info = answersInfo();
    var percent = info.total ? Math.round((info.correct / info.total) * 100) : 0;
    var level = resultLevel(percent);
    var name = $('#student-surname').val().trim() + ' ' + $('#student-name').val().trim();

    var record = {
      updated: new Date().toISOString(),
      name: name,
      group: $('#student-group').val().trim(),
      checkDate: $('#check-date').val().trim(),
      email: $('#student-email').val().trim(),
      checkNumber: $('#check-number').val().trim(),
      correct: info.correct,
      total: info.total,
      percent: percent,
      level: level,
      selfLevel: Number($slider.val())
    };

    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(record)); } catch (err) { /* ignore */ }

    $('#result-summary').html(
      '<strong>' + name + '</strong> (' + record.group + '), проверка № ' + record.checkNumber +
      ' от ' + record.checkDate + '.<br>' +
      'Правильных ответов: <strong>' + info.correct + ' из ' + info.total + '</strong> (' +
      percent + '%).<br>' +
      'Уровень: <strong>' + level + '</strong>. Самооценка уверенности: ' + record.selfLevel + ' из 10.'
    );
    $('#result-confirm').text(
      'Результат сохранён автоматически (ключ portal-knowledge-result). Спасибо за прохождение проверки!'
    );
    if (resultModal) resultModal.show();

    $('#form-status').attr('class', 'form-status form-status--ok')
      .text('Проверка завершена. Результат показан в окне и сохранён в браузере.');
  });

  /* Живое снятие ошибок при вводе */
  $form.on('input', 'input', function () {
    $(this).closest('.kn-field').removeClass('is-invalid');
    $(this).removeClass('is-invalid').removeAttr('aria-invalid');
    $('#' + $(this).attr('id') + '-error').text('');
  });

  refreshAnswers();
})(jQuery);