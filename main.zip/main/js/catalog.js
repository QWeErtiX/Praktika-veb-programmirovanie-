/* =========================================================
   catalog.js — динамический каталог записей (Bootstrap-версия)
   • Загрузка данных: $.getJSON('assets/data/records.json')
     с офлайн-фолбэком на window.PORTAL_RECORDS (records-data.js)
   • Живые фильтры: поиск по тексту + раздел проекта
   • Сортировка: наименование / дата (возр./убыв.)
   • Постраничная навигация (Bootstrap .pagination)
   • Статистика по разделам и категориям
   ========================================================= */
(function () {
  'use strict';

  var $ = window.jQuery;
  if (!$) return;

  var PAGE_SIZE = 6;
  var SECTION_LABELS = { 1: 'Раздел 1', 2: 'Раздел 2', 3: 'Раздел 3' };
  var SECTION_BADGE = { 1: 'text-bg-primary', 2: 'text-bg-info text-dark', 3: 'text-bg-success' };

  var DATA = [];
  var page = 1;

  var $body = $('#catalog-body');
  var $count = $('#catalog-count');
  var $loading = $('#catalog-loading');
  var $error = $('#catalog-error');
  var $empty = $('#catalog-empty');
  var $pagination = $('#catalog-pagination');
  var $form = $('#filterForm');
  var $search = $('#q');
  var $section = $('#sec');
  var $sort = $('#sort');
  var $reset = $('#reset');

  /* ---------- Утилиты ---------- */
  function escapeHtml(value) {
    return String(value).replace(/[&<>"]/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch];
    });
  }

  function highlight(text, query) {
    if (!query) return escapeHtml(text);
    var pattern = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    var out = '', last = 0, m;
    while ((m = pattern.exec(text)) !== null) {
      out += escapeHtml(text.slice(last, m.index));
      out += '<mark>' + escapeHtml(m[0]) + '</mark>';
      last = m.index + m[0].length;
      if (m.index === pattern.lastIndex) pattern.lastIndex++;
    }
    return out + escapeHtml(text.slice(last));
  }

  function formatDate(iso) {
    var p = String(iso).split('-');
    return p.length === 3 ? p[2] + '.' + p[1] + '.' + p[0] : iso;
  }

  function shortCategory(cat) {
    return String(cat).split(' ')[0];
  }

  /* ---------- Выборка с учётом фильтров и сортировки ---------- */
  function selectRecords() {
    var query = $search.val().trim().toLowerCase();
    var section = $section.val();
    var mode = $sort.val();

    var rows = DATA.filter(function (r) {
      if (section !== '0' && String(r.section) !== section) return false;
      if (!query) return true;
      var haystack = (r.name + ' ' + r.category + ' ' + r.number + ' ' + r.annotation).toLowerCase();
      return haystack.indexOf(query) !== -1;
    });

    rows.sort(function (a, b) {
      if (mode === 'name-asc') return a.name.localeCompare(b.name, 'ru');
      return mode === 'date-asc' ? a.date.localeCompare(b.date) : b.date.localeCompare(a.date);
    });
    return rows;
  }

  /* ---------- Постраничная навигация Bootstrap ---------- */
  function paginationItem(label, target, disabled, active) {
    if (disabled) return '<li class="page-item disabled"><span class="page-link">' + label + '</span></li>';
    if (active) return '<li class="page-item active" aria-current="page"><span class="page-link">' + label + '</span></li>';
    return '<li class="page-item"><a class="page-link" href="#!" data-page="' + target + '">' + label + '</a></li>';
  }

  function renderPagination(pages) {
    if (pages <= 1) { $pagination.empty(); return; }

    var out = paginationItem('Назад', page - 1, page === 1, false);
    var from = Math.max(1, page - 2);
    var to = Math.min(pages, page + 2);

    if (from > 1) {
      out += paginationItem('1', 1, false, false);
      if (from > 2) out += '<li class="page-item disabled"><span class="page-link">…</span></li>';
    }
    for (var p = from; p <= to; p++) out += paginationItem(String(p), p, false, p === page);
    if (to < pages) {
      if (to < pages - 1) out += '<li class="page-item disabled"><span class="page-link">…</span></li>';
      out += paginationItem(String(pages), pages, false, false);
    }
    out += paginationItem('Вперёд', page + 1, page === pages, false);

    $pagination.html('<ul class="pagination justify-content-center mb-0">' + out + '</ul>');
  }

  /* ---------- Отрисовка таблицы ---------- */
  function render() {
    var rows = selectRecords();
    var pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
    if (page > pages) page = pages;
    var start = (page - 1) * PAGE_SIZE;
    var slice = rows.slice(start, start + PAGE_SIZE);
    var query = $search.val().trim().toLowerCase();

    $count.text(
      'Найдено записей: ' + rows.length + ' из ' + DATA.length +
      (pages > 1 ? ' • страница ' + page + ' из ' + pages : '')
    );

    if (!rows.length) {
      $body.empty();
      $empty.removeAttr('hidden');
      $pagination.empty();
      return;
    }
    $empty.attr('hidden', '');

    var html = slice.map(function (r, i) {
      return '' +
        '<tr>' +
          '<td class="text-secondary">' + (start + i + 1) + '</td>' +
          '<td>' + highlight(r.name, query) + '</td>' +
          '<td><span class="badge text-bg-secondary">' + escapeHtml(shortCategory(r.category)) + '</span></td>' +
          '<td><code>' + highlight(r.number, query) + '</code></td>' +
          '<td class="text-nowrap">' + escapeHtml(formatDate(r.date)) + '</td>' +
          '<td><span class="badge ' + (SECTION_BADGE[r.section] || 'text-bg-secondary') + '">' +
            (SECTION_LABELS[r.section] || escapeHtml(r.section)) + '</span></td>' +
        '</tr>';
    }).join('');

    $body.html(html);
    renderPagination(pages);
  }

  /* ---------- Статистика по каталогу ---------- */
  function renderStats() {
    var bySection = {};
    var categories = {};
    DATA.forEach(function (r) {
      bySection[r.section] = (bySection[r.section] || 0) + 1;
      categories[r.category] = 1;
    });

    $('#stat-total').text(DATA.length);
    $('#stat-sections').text([1, 2, 3].filter(function (s) { return bySection[s]; }).length);
    $('#stat-categories').text(Object.keys(categories).length);
    [1, 2, 3].forEach(function (s) { $('#stat-sec-' + s).text(bySection[s] || 0); });
  }

  /* ---------- Загрузка данных ---------- */
  function start(data) {
    $loading.attr('hidden', '');
    DATA = Array.isArray(data) ? data : [];
    if (!DATA.length) {
      $count.text('Записей: 0');
      $empty.removeAttr('hidden');
      return;
    }
    renderStats();
    render();
  }

  /* Занятие 11: уведомление (Bootstrap toast). Дублирует, но не заменяет
     постоянное сообщение #catalog-error — важное остаётся на странице. */
  function notify(text, kind) {
    var el = document.getElementById('catalog-toast');
    if (!el || !window.bootstrap) return;
    el.className = 'toast align-items-center border-0 text-bg-' + kind;
    $('#catalog-toast-text').text(text);
    bootstrap.Toast.getOrCreateInstance(el, { delay: 6000 }).show();
  }

  function load() {
    $loading.removeAttr('hidden');
    $error.attr('hidden', '');
    $empty.attr('hidden', '');

    $.getJSON('assets/data/records.json')
      .done(function (data) { start(data); })
      .fail(function () {
        if (Array.isArray(window.PORTAL_RECORDS) && window.PORTAL_RECORDS.length) {
          start(window.PORTAL_RECORDS);
          notify('Файл records.json недоступен — показаны резервные данные каталога.', 'warning');
        } else {
          $loading.attr('hidden', '');
          $count.text('Загрузка не выполнена');
          $error.removeAttr('hidden');
          notify('Ошибка загрузки данных каталога. Проверьте подключение и обновите страницу.', 'danger');
        }
      });
  }

  /* ---------- События ---------- */
  $form.on('submit', function (e) { e.preventDefault(); page = 1; render(); });
  $search.on('input', function () { page = 1; render(); });
  $section.on('change', function () { page = 1; render(); });
  $sort.on('change', function () { page = 1; render(); });
  $reset.on('click', function () {
    $search.val('');
    $section.val('0');
    $sort.val('name-asc');
    page = 1;
    render();
  });
  $pagination.on('click', 'a.page-link[data-page]', function (e) {
    e.preventDefault();
    page = parseInt($(this).attr('data-page'), 10) || 1;
    render();
  });

  load();
})();
